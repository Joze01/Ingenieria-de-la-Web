<?php 
	require 'functions.php';
	loginUser();
?>