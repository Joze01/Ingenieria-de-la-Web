<?php 
	include 'functions.php';
	deleteContact();
?>