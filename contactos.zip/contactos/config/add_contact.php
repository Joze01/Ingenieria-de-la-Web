<?php 
	include 'functions.php';
	addContact();
?>