<?php
	include 'functions.php';
	addUser();
?>
