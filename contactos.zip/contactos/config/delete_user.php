<?php
	include 'functions.php';
	deleteUser();
?>
