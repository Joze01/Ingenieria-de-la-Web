<?php
	include 'functions.php';
	updateContact();
?>
